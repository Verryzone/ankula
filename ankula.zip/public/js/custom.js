function push_state(id) {
      $('#id-delete').val(id)

      console.log(id)
}

