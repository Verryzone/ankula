import './bootstrap';
import 'flowbite';
import 'flowbite-datepicker';
import $ from 'jquery';
window.$ = $;
window.jQuery = $;

import Alpine from 'alpinejs';
window.Alpine = Alpine;

Alpine.start();

