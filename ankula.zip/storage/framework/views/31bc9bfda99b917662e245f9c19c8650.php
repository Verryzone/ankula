<?php if (isset($component)) { $__componentOriginal03cc9e4f7c7052747874d6742a181922 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal03cc9e4f7c7052747874d6742a181922 = $attributes; } ?>
<?php $component = App\View\Components\ManagementAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('management-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ManagementAppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-11 lg:px-3">
        <div class="px-8 pt-2 bg-white block sm:flex items-center justify-between border-b rounded-t-lg border-gray-200 lg:mt-1.5 dark:bg-gray-800 dark:border-gray-700">
            <div class="w-full mb-5">
                <div class="mb-2 py-4">
                    <nav class="flex mb-5" aria-label="Breadcrumb">
                        <ol class="inline-flex items-center space-x-1 text-sm font-medium md:space-x-2">
                            <li class="inline-flex items-center">
                                <a href="<?php echo e(route('management.index')); ?>" class="inline-flex items-center text-gray-700 hover:text-primary-600 dark:text-gray-300 dark:hover:text-white">
                                    <svg class="w-5 h-5 mr-2.5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                                    </svg>
                                    Home
                                </a>
                            </li>
                            <li>
                                <div class="flex items-center">
                                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                    </svg>
                                    <a href="<?php echo e(route('management.orders.index')); ?>" class="ml-1 text-gray-700 hover:text-primary-600 md:ml-2 dark:text-gray-300 dark:hover:text-white">Orders</a>
                                </div>
                            </li>
                            <li>
                                <div class="flex items-center">
                                    <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path>
                                    </svg>
                                    <span class="ml-1 text-gray-400 md:ml-2 dark:text-gray-500" aria-current="page">Order #<?php echo e($order->order_number); ?></span>
                                </div>
                            </li>
                        </ol>
                    </nav>
                    <div class="flex items-center justify-between">
                        <h1 class="text-lg font-semibold text-gray-900 sm:text-2xl dark:text-white">Order #<?php echo e($order->order_number); ?></h1>
                        <a href="<?php echo e(route('management.orders.index')); ?>" class="inline-flex items-center px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:ring-4 focus:ring-gray-300">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                            </svg>
                            Back to Orders
                        </a>
                    </div>
                </div>

                <!-- Success/Error Messages -->
                <?php if(session('success')): ?>
                    <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                            </svg>
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                            </svg>
                            <?php echo e(session('error')); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
            <!-- Main Content -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Order Info -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <h2 class="text-xl font-semibold mb-4">Order Information</h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h3 class="font-medium text-gray-900 mb-3">Order Details</h3>
                            <div class="space-y-2 text-sm">
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Order Number:</span>
                                    <span class="font-medium">#<?php echo e($order->order_number); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Order ID:</span>
                                    <span class="font-medium"><?php echo e($order->id); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Order Date:</span>
                                    <span class="font-medium"><?php echo e($order->created_at->format('M d, Y H:i')); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Current Status:</span>
                                    <?php
                                        $statusClasses = [
                                            'pending' => 'bg-yellow-100 text-yellow-800',
                                            'processing' => 'bg-blue-100 text-blue-800',
                                            'completed' => 'bg-green-100 text-green-800',
                                            'cancelled' => 'bg-red-100 text-red-800'
                                        ];
                                        $statusLabels = [
                                            'pending' => 'Pending',
                                            'processing' => 'Processing',
                                            'completed' => 'Completed',
                                            'cancelled' => 'Cancelled'
                                        ];
                                    ?>
                                    <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo e($statusClasses[$order->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                        <?php echo e($statusLabels[$order->status] ?? ucfirst($order->status)); ?>

                                    </span>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h3 class="font-medium text-gray-900 mb-3">Customer Information</h3>
                            <div class="space-y-2 text-sm">
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Name:</span>
                                    <span class="font-medium"><?php echo e($order->user->name); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Email:</span>
                                    <span class="font-medium"><?php echo e($order->user->email); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Customer ID:</span>
                                    <span class="font-medium"><?php echo e($order->user->id); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Order Items -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <h2 class="text-xl font-semibold mb-4">Order Items</h2>
                    
                    <div class="space-y-4">
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex items-center gap-4 p-4 border border-gray-200 rounded-lg">
                                <?php if($item->product->image): ?>
                                    <img src="<?php echo e(asset('storage/products/images/' . $item->product->image)); ?>" 
                                         alt="<?php echo e($item->product->name); ?>" 
                                         class="w-16 h-16 object-cover rounded-lg">
                                <?php else: ?>
                                    <div class="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="flex-1">
                                    <h3 class="font-semibold text-gray-900"><?php echo e($item->product->name); ?></h3>
                                    <?php if($item->product->category): ?>
                                        <p class="text-sm text-gray-600 mb-2"><?php echo e($item->product->category->name); ?></p>
                                    <?php endif; ?>
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm text-gray-600">Qty: <?php echo e($item->quantity); ?></span>
                                        <div class="text-right">
                                            <p class="text-sm text-gray-600">@ Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></p>
                                            <p class="font-semibold">Rp <?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Payment Information -->
                <?php if($order->payment): ?>
                    <div class="bg-white rounded-lg shadow-sm border p-6">
                        <h2 class="text-xl font-semibold mb-4">Payment Information</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <p class="text-sm text-gray-600">Payment Method</p>
                                <p class="font-medium"><?php echo e(ucfirst($order->payment->payment_method)); ?></p>
                            </div>
                            
                            <div>
                                <p class="text-sm text-gray-600">Payment Status</p>
                                <?php
                                    $paymentClasses = [
                                        'pending' => 'bg-yellow-100 text-yellow-800',
                                        'success' => 'bg-green-100 text-green-800',
                                        'failed' => 'bg-red-100 text-red-800',
                                        'expired' => 'bg-gray-100 text-gray-800'
                                    ];
                                    $paymentLabels = [
                                        'pending' => 'Unpaid',
                                        'success' => 'Paid',
                                        'failed' => 'Failed',
                                        'expired' => 'Expired'
                                    ];
                                ?>
                                <span class="inline-block px-3 py-1 rounded-full text-xs font-medium <?php echo e($paymentClasses[$order->payment->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                    <?php echo e($paymentLabels[$order->payment->status] ?? ucfirst($order->payment->status)); ?>

                                </span>
                            </div>
                            
                            <?php if($order->payment->paid_at): ?>
                                <div>
                                    <p class="text-sm text-gray-600">Payment Date</p>
                                    <p class="font-medium"><?php echo e(\Carbon\Carbon::parse($order->payment->paid_at)->format('M d, Y H:i')); ?></p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if($order->payment->payment_reference): ?>
                                <div>
                                    <p class="text-sm text-gray-600">Payment Reference</p>
                                    <p class="font-medium font-mono text-sm"><?php echo e($order->payment->payment_reference); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Order Status Management -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <h2 class="text-xl font-semibold mb-4">Update Order Status</h2>
                    
                    <form method="POST" action="<?php echo e(route('management.orders.update-status', $order->id)); ?>" onsubmit="return confirmStatusUpdate()">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        
                        <div class="mb-4">
                            <label for="status" class="block text-sm font-medium text-gray-700 mb-2">Select New Status</label>
                            <select name="status" id="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="pending" <?php echo e($order->status === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="processing" <?php echo e($order->status === 'processing' ? 'selected' : ''); ?>>Processing</option>
                                <option value="completed" <?php echo e($order->status === 'completed' ? 'selected' : ''); ?>>Completed</option>
                                <option value="cancelled" <?php echo e($order->status === 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-300">
                            Update Status
                        </button>
                    </form>
                </div>

                <!-- Order Summary -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <h2 class="text-xl font-semibold mb-4">Order Summary</h2>
                    
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Subtotal (<?php echo e($order->orderItems->sum('quantity')); ?> items)</span>
                            <span class="font-medium">Rp <?php echo e(number_format($order->orderItems->sum(function($item) { return $item->price * $item->quantity; }), 0, ',', '.')); ?></span>
                        </div>
                        
                        <div class="flex justify-between">
                            <span class="text-gray-600">Shipping Cost</span>
                            <span class="font-medium">Rp <?php echo e(number_format($order->shipping_cost ?? 0, 0, ',', '.')); ?></span>
                        </div>
                        
                        <div class="border-t pt-3">
                            <div class="flex justify-between text-lg font-bold">
                                <span>Total</span>
                                <span>Rp <?php echo e(number_format($order->total_amount + $order->shipping_cost, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Shipping Address -->
                <?php if($order->shippingAddress || $order->shipping_address_snapshot): ?>
                    <div class="bg-white rounded-lg shadow-sm border p-6">
                        <h2 class="text-xl font-semibold mb-4">Shipping Address</h2>
                        
                        <div class="text-gray-700">
                            <?php if($order->shippingAddress): ?>
                                <p class="font-medium"><?php echo e($order->shippingAddress->name); ?></p>
                                <p class="text-sm text-gray-600 mb-2"><?php echo e($order->shippingAddress->phone); ?></p>
                                <p><?php echo e($order->shippingAddress->address); ?></p>
                                <p><?php echo e($order->shippingAddress->city); ?>, <?php echo e($order->shippingAddress->postal_code); ?></p>
                                <p><?php echo e($order->shippingAddress->province); ?></p>
                            <?php elseif($order->shipping_address_snapshot): ?>
                                <?php 
                                    $snapshot = $order->shipping_address_snapshot; 
                                ?>
                                <p class="font-medium"><?php echo e($snapshot['name'] ?? 'Name not available'); ?></p>
                                <p class="text-sm text-gray-600 mb-2"><?php echo e($snapshot['phone'] ?? ''); ?></p>
                                <p><?php echo e($snapshot['address'] ?? 'Address not available'); ?></p>
                                <p><?php echo e($snapshot['city'] ?? ''); ?>, <?php echo e($snapshot['postal_code'] ?? ''); ?></p>
                                <?php if(isset($snapshot['province'])): ?>
                                    <p><?php echo e($snapshot['province']); ?></p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow-sm border p-6">
                    <h2 class="text-xl font-semibold mb-4">Quick Actions</h2>
                    
                    <div class="space-y-3">
                        <?php if($order->status === 'pending'): ?>
                            <button onclick="quickStatusUpdate('processing')" class="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-300">
                                Mark as Processing
                            </button>
                        <?php endif; ?>
                        
                        <?php if($order->status === 'processing'): ?>
                            <button onclick="quickStatusUpdate('completed')" class="w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition duration-300">
                                Mark as Completed
                            </button>
                        <?php endif; ?>
                        
                        <?php if($order->status !== 'cancelled' && $order->status !== 'completed'): ?>
                            <button onclick="quickStatusUpdate('cancelled')" class="w-full px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-300">
                                Cancel Order
                            </button>
                        <?php endif; ?>
                        
                        <a href="<?php echo e(route('management.orders.index')); ?>" class="block w-full px-4 py-2 bg-gray-600 text-white text-center rounded-md hover:bg-gray-700 transition duration-300">
                            Back to All Orders
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmStatusUpdate() {
            const newStatus = document.getElementById('status').value;
            const currentStatus = '<?php echo e($order->status); ?>';
            
            if (newStatus === currentStatus) {
                alert('Status is already set to ' + newStatus);
                return false;
            }
            
            return confirm('Are you sure you want to change the order status to "' + newStatus + '"?');
        }

        function quickStatusUpdate(status) {
            if (confirm('Are you sure you want to change the order status to "' + status + '"?')) {
                // Create a form and submit it
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '<?php echo e(route("management.orders.update-status", $order->id)); ?>';
                
                // Add CSRF token
                const csrfToken = document.createElement('input');
                csrfToken.type = 'hidden';
                csrfToken.name = '_token';
                csrfToken.value = '<?php echo e(csrf_token()); ?>';
                form.appendChild(csrfToken);
                
                // Add method override
                const methodOverride = document.createElement('input');
                methodOverride.type = 'hidden';
                methodOverride.name = '_method';
                methodOverride.value = 'PATCH';
                form.appendChild(methodOverride);
                
                // Add status input
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = status;
                form.appendChild(statusInput);
                
                // Submit the form
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal03cc9e4f7c7052747874d6742a181922)): ?>
<?php $attributes = $__attributesOriginal03cc9e4f7c7052747874d6742a181922; ?>
<?php unset($__attributesOriginal03cc9e4f7c7052747874d6742a181922); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal03cc9e4f7c7052747874d6742a181922)): ?>
<?php $component = $__componentOriginal03cc9e4f7c7052747874d6742a181922; ?>
<?php unset($__componentOriginal03cc9e4f7c7052747874d6742a181922); ?>
<?php endif; ?>
<?php /**PATH D:\Universitas Duta Bangsa\Semester 4\Pemrograman Web\ankulaa\resources\views/management/pages/orders/detail.blade.php ENDPATH**/ ?>