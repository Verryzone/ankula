<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Success/Error Messages -->
            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                        </svg>
                        <?php echo e(session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                        </svg>
                        <?php echo e(session('error')); ?>

                    </div>
                </div>
            <?php endif; ?>

            <!-- Header -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">Pesanan Saya</h1>
                <p class="text-gray-600">Kelola dan pantau status pesanan Anda</p>
            </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <div class="text-2xl font-bold text-blue-600"><?php echo e($stats['total']); ?></div>
            <div class="text-sm text-gray-600">Total Pesanan</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <div class="text-2xl font-bold text-yellow-600"><?php echo e($stats['pending']); ?></div>
            <div class="text-sm text-gray-600">Menunggu Pembayaran</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <div class="text-2xl font-bold text-blue-600"><?php echo e($stats['processing']); ?></div>
            <div class="text-sm text-gray-600">Diproses</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <div class="text-2xl font-bold text-green-600"><?php echo e($stats['completed']); ?></div>
            <div class="text-sm text-gray-600">Selesai</div>
        </div>
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <div class="text-2xl font-bold text-red-600"><?php echo e($stats['cancelled']); ?></div>
            <div class="text-sm text-gray-600">Dibatalkan</div>
        </div>
    </div>

    <!-- Filters -->
    <div class="bg-white p-6 rounded-lg shadow-sm border mb-6">
        <form method="GET" action="<?php echo e(route('orders.index')); ?>" class="flex flex-col lg:flex-row gap-4">
            <!-- Search -->
            <div class="flex-1">
                <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Cari Pesanan</label>
                <input type="text" 
                       id="search" 
                       name="search" 
                       value="<?php echo e($search); ?>"
                       placeholder="Nomor pesanan atau nama produk..."
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            
            <!-- Status Filter -->
            <div>
                <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select name="status" id="status" class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="all" <?php echo e($status == 'all' ? 'selected' : ''); ?>>Semua Status</option>
                    <option value="pending" <?php echo e($status == 'pending' ? 'selected' : ''); ?>>Menunggu Pembayaran</option>
                    <option value="processing" <?php echo e($status == 'processing' ? 'selected' : ''); ?>>Diproses</option>
                    <option value="completed" <?php echo e($status == 'completed' ? 'selected' : ''); ?>>Selesai</option>
                    <option value="cancelled" <?php echo e($status == 'cancelled' ? 'selected' : ''); ?>>Dibatalkan</option>
                </select>
            </div>
            
            <!-- Submit Button -->
            <div class="flex items-end">
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-300">
                    Filter
                </button>
            </div>
        </form>
    </div>

    <!-- Orders List -->
    <?php if($orders->count() > 0): ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow-sm border overflow-hidden">
                    <!-- Order Header -->
                    <div class="p-4 bg-gray-50 border-b border-gray-200 flex flex-col lg:flex-row lg:items-center lg:justify-between">
                        <div class="mb-2 lg:mb-0">
                            <h3 class="font-semibold text-gray-900">
                                Order #<?php echo e($order->order_number); ?>

                            </h3>
                            <p class="text-sm text-gray-600">
                                <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d M Y, H:i')); ?>

                            </p>
                        </div>
                        
                        <div class="flex items-center gap-3">
                            <!-- Order Status -->
                            <?php
                                $statusClasses = [
                                    'pending' => 'bg-yellow-100 text-yellow-800',
                                    'processing' => 'bg-blue-100 text-blue-800',
                                    'completed' => 'bg-green-100 text-green-800',
                                    'cancelled' => 'bg-red-100 text-red-800'
                                ];
                                $statusLabels = [
                                    'pending' => 'Menunggu Pembayaran',
                                    'processing' => 'Diproses',
                                    'completed' => 'Selesai',
                                    'cancelled' => 'Dibatalkan'
                                ];
                            ?>
                            <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo e($statusClasses[$order->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                <?php echo e($statusLabels[$order->status] ?? ucfirst($order->status)); ?>

                            </span>
                            
                            <!-- Payment Status -->
                            <?php if($order->payment): ?>
                                <?php
                                    $paymentClasses = [
                                        'pending' => 'bg-yellow-100 text-yellow-800',
                                        'success' => 'bg-green-100 text-green-800',
                                        'failed' => 'bg-red-100 text-red-800',
                                        'expired' => 'bg-gray-100 text-gray-800'
                                    ];
                                    $paymentLabels = [
                                        'pending' => 'Belum Bayar',
                                        'success' => 'Lunas',
                                        'failed' => 'Gagal',
                                        'expired' => 'Kadaluarsa'
                                    ];
                                ?>
                                <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo e($paymentClasses[$order->payment->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                    <?php echo e($paymentLabels[$order->payment->status] ?? ucfirst($order->payment->status)); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Order Items Preview -->
                    <div class="p-4">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                            <!-- Items -->
                            <div class="lg:col-span-2">
                                <h4 class="font-medium text-gray-900 mb-3">Produk (<?php echo e($order->orderItems->count()); ?> item)</h4>
                                <div class="space-y-2">
                                    <?php $__currentLoopData = $order->orderItems->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-center gap-3">
                                            <?php if($item->product->image): ?>
                                                <img src="<?php echo e(asset('storage/products/images/' . $item->product->image)); ?>" 
                                                     alt="<?php echo e($item->product->name); ?>" 
                                                     class="w-12 h-12 object-cover rounded">
                                            <?php else: ?>
                                                <div class="w-12 h-12 bg-gray-200 rounded flex items-center justify-center">
                                                    <svg class="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                                    </svg>
                                                </div>
                                            <?php endif; ?>
                                            <div class="flex-1">
                                                <p class="font-medium text-sm"><?php echo e($item->product->name); ?></p>
                                                <p class="text-xs text-gray-600"><?php echo e($item->quantity); ?>x @ Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></p>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php if($order->orderItems->count() > 2): ?>
                                        <p class="text-sm text-gray-600">
                                            +<?php echo e($order->orderItems->count() - 2); ?> produk lainnya
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Total & Actions -->
                            <div class="text-right">
                                <div class="mb-4">
                                    <p class="text-sm text-gray-600">Total Pesanan</p>
                                    <p class="text-xl font-bold text-gray-900">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></p>
                                </div>
                                
                                <div class="space-y-2">
                                    <a href="<?php echo e(route('orders.show', $order->id)); ?>" 
                                       class="block w-full px-4 py-2 bg-blue-600 text-white text-center rounded-md hover:bg-blue-700 transition duration-300">
                                        Lihat Detail
                                    </a>
                                    
                                    <?php if($order->status === 'pending' && $order->payment && $order->payment->status === 'pending'): ?>
                                        <a href="<?php echo e(route('payment.retry', $order->id)); ?>" 
                                           class="block w-full px-4 py-2 bg-green-600 text-white text-center rounded-md hover:bg-green-700 transition duration-300">
                                            Bayar Sekarang
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if($order->status === 'pending'): ?>
                                        <form action="<?php echo e(route('orders.cancel', $order->id)); ?>" method="POST" 
                                              onsubmit="return confirm('Apakah Anda yakin ingin membatalkan pesanan ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" 
                                                    class="w-full px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-300">
                                                Batalkan Pesanan
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="mt-8">
            <?php echo e($orders->appends(request()->query())->links()); ?>

        </div>
    <?php else: ?>
        <!-- Empty State -->
        <div class="bg-white rounded-lg shadow-sm border p-8 text-center">
            <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
            </svg>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Belum Ada Pesanan</h3>
            <p class="text-gray-600 mb-6">Anda belum memiliki pesanan apapun. Mulai berbelanja sekarang!</p>
            <a href="<?php echo e(route('dashboard')); ?>" 
               class="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition duration-300">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
                </svg>
                Mulai Belanja
            </a>
        </div>
    <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Universitas Duta Bangsa\Semester 4\Pemrograman Web\ankulaa\resources\views/pages/orders/index.blade.php ENDPATH**/ ?>