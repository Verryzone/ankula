<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.7/dist/axios.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script>
        if (localStorage.getItem('color-theme') === 'dark') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>
</head>

<body class="font-sans antialiased bg-gray-200">
    <div class="min-h-screen">
        <?php echo $__env->make('management.layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Main container aligned with navbar -->
        <div class="max-w-screen-xl mx-auto flex min-h-screen">
            <aside class="w-64 flex-shrink-0 min-h-screen overflow-hidden">
                <?php echo $__env->make('management.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </aside>
            <div class="flex-1 mt-6 min-h-screen">
                <!-- Page Content -->
                <main>
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('api/private-axios.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\Universitas Duta Bangsa\Semester 4\Pemrograman Web\ankulaa\resources\views/management/layouts/app.blade.php ENDPATH**/ ?>